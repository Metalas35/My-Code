———————————
Disclaimer
———————————
I do not own any rights to this game. This game is part of the Suikoden IV as a mini-game. I simply created it to gain programming experience and because there was no version of it anywhere.

———————————
How to use
———————————
Simply run the "Fifty-One.jar".


Instructions on how to play the game can be found inside.

Have fun and enjoy the game!

Made by Metalas35