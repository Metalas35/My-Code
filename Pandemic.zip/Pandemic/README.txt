———————————
Disclaimer
———————————
I do not own any rights to this game. This game was originally designed by Matt Leacock. I simply created it to gain programming experience.

———————————
How to use
———————————
Simply run the "Pandemic - The Game.jar" located inside the Pandemic folder. This is a free, very simple version of the game. 
   In order to be played by many players simultaneously, a screen share program (Discord, Skype etc) needs to be used. Also, it is best to use an image editing program (Photoshop, GIMP etc) in order to display the board and dynamically change it. The board and the pawns, infections and other crucial components are found in the images\Misc folder.

For more instructions on how to play the game, check the "Instructions.png" file in the images folder


Have fun and enjoy the game!

Made by Metalas35